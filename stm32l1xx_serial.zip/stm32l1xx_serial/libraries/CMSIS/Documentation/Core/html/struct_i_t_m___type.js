var struct_i_t_m___type =
[
    [ "PORT", "struct_i_t_m___type.html#afe056e8c8f8c5519d9b47611fa3a4c46", null ],
    [ "RESERVED0", "struct_i_t_m___type.html#a2c5ae30385b5f370d023468ea9914c0e", null ],
    [ "RESERVED1", "struct_i_t_m___type.html#afffce5b93bbfedbaee85357d0b07ebce", null ],
    [ "RESERVED2", "struct_i_t_m___type.html#af56b2f07bc6b42cd3e4d17e1b27cff7b", null ],
    [ "TCR", "struct_i_t_m___type.html#a58f169e1aa40a9b8afb6296677c3bb45", null ],
    [ "TER", "struct_i_t_m___type.html#a91a040e1b162e1128ac1e852b4a0e589", null ],
    [ "TPR", "struct_i_t_m___type.html#a93b480aac6da620bbb611212186d47fa", null ],
    [ "u16", "struct_i_t_m___type.html#a12aa4eb4d9dcb589a5d953c836f4e8f4", null ],
    [ "u32", "struct_i_t_m___type.html#a6882fa5af67ef5c5dfb433b3b68939df", null ],
    [ "u8", "struct_i_t_m___type.html#abea77b06775d325e5f6f46203f582433", null ]
];